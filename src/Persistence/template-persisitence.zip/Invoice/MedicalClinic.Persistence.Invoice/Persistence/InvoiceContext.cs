﻿using System;
using MedicalClinic.Domain.Invoice.Entities;
using MedicalClinic.Domain.Invoice.Interfaces;
using Spin.Modules.API.Base;

namespace MedicalClinic.Persistence.Invoice.Persistence
{

    /// <summary>
    /// Invoice Context Database
    /// </summary>
    public class InvoiceContext: BaseBL<InvoiceItem>, IInvoiceContext
    {
        public InvoiceContext()
            :base("Invoice")
        {

        }
    }
}
