require('./common.js');
var MODULE_NAME = 'ui.bootstrap.module.common';

angular.module(MODULE_NAME, ['ui.bootstrap.common']);

module.exports = MODULE_NAME;
