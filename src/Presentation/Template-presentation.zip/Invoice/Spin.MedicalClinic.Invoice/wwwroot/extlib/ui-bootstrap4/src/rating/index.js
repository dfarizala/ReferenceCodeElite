require('../common/svg-icon.css');
module.exports = require('./index-nocss.js');
