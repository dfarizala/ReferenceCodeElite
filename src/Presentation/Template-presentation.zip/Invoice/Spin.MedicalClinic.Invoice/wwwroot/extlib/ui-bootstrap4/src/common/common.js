angular.module('ui.bootstrap.common', []);
