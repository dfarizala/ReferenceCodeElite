require('../common/svg-icon.css');
require('./timepicker.css');
module.exports = require('./index-nocss.js');
