﻿var helperSpin = {
    showLoading: function () {
        $("#loadingSpin").show();
    },
    hideLoading: function () {
        $("#loadingSpin").hide();
    },
    reziseImage: function(URL) {
        //Not bulinding
    }
}