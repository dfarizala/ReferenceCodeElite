﻿
var autocompletePlugin = function ($scope, $http, $filter) {
    $scope.ok = function () {
        alert("OK");
    }
}
