module.exports = function(){
    console.log("  ______    _______    _____   ____  _____ ");
    console.log(".' ____ \\  |_   __ \\  |_   _| |_   \\|_   _| ");
    console.log("| (___ \\_|   | |__) |   | |     |   \\ | |   ");
    console.log(" _.____`.    |  ___/    | |     | |\\ \\| |   ");
    console.log("| \\____) |  _| |_      _| |_   _| |_\\   |_  ");
    console.log(" \\______.' |_____|    |_____| |_____|\\____| ");
    console.log("    ______                                             __  ");
    console.log("   / ____/________ _____ ___  ___ _      ______  _____/ /__");
    console.log("  / /_  / ___/ __ `/ __ `__ \\/ _ \\ | /| / / __ \\/ ___/ //_/ ");
    console.log(" / __/ / /  / /_/ / / / / / /  __/ |/ |/ / /_/ / /  / ,<   ");
    console.log("/_/   /_/   \\__,_/_/ /_/ /_/\\___/|__/|__/\\____/_/  /_/|_|  ");
    console.log();
    console.log("Typescript - Less  Version" );
    console.log("SPIN WEB FRAMEWORK - all reserved rights");
    console.log("https://www.spinwebframework.com");
}