﻿using System;
using System.Threading.Tasks;
using MedicalClinic.Domain.Common.Wrappers;
using MedicalClinic.Domain.Invoice.DTO.Response;
using MedicalClinic.Domain.Invoice.Entities.Request;
using MedicalClinic.Domain.Invoice.Entities.Response;
using MedicalClinic.Domain.Invoice.Interfaces.Application;
using Microsoft.AspNetCore.Mvc;
using Spin.Base.BaseController;
using Spin.Base.Route;
using Spin.Modules.Entity.Controllers;

namespace Spin.MedicalClinic.Invoice.Spin.Module.Invoice.Api.Controllers
{
    [SpinRoute("Api/Invoice", "Api", "Invoice", "Invoice")]
    [ControllerInformation("Estate")]
    public class InvoiceController: SpinControllerApi
    {
        private IInvoiceApplication _invoiceApplciation;


        public InvoiceController(IInvoiceApplication invoiceApplciation)
        {
            _invoiceApplciation = invoiceApplciation;
        }


        [HttpPost("GetInvoice")]
        async public Task<Response<ResponseSingleInvoiceDto>> GetInvoice([FromBody] RequestInvoice request)
        {

            return  await _invoiceApplciation.GetInvoice(request);
        }

       
    }
}
