﻿using System;
using System.Threading.Tasks;
using MedicalClinic.Domain.Interfaces.Base;
using MedicalClinic.Domain.Invoice.Entities;


namespace MedicalClinic.Domain.Invoice.Interfaces
{
    public interface IInvoiceContext: IBaseCommonBL<InvoiceItem, int>
    {
        
    }
}
