﻿using System;
using System.Threading.Tasks;
using MedicalClinic.Domain.Common.Wrappers;
using MedicalClinic.Domain.Invoice.DTO.Response;
using MedicalClinic.Domain.Invoice.Entities;
using MedicalClinic.Domain.Invoice.Entities.Request;

namespace MedicalClinic.Domain.Invoice.Interfaces.Application
{
    public interface IInvoiceApplication
    {
        Task<Response<ResponseSingleInvoiceDto>> GetInvoice(RequestInvoice request);
    }
}
