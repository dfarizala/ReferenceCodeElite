﻿using System;
using MediatR;
using MedicalClinic.Domain.Invoice.Entities.Response;
using MedicalClinic.Domain.Common.Wrappers;

namespace MedicalClinic.Domain.Invoice.Entities.Request
{
    public class RequestInvoice : IRequest<Response<ResposeSingleInvoice>>
    {
        public RequestInvoice()
        {
        }

        public int Id { get; set; }
    }
}
