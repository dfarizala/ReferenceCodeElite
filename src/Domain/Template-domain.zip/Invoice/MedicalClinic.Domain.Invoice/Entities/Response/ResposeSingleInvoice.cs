﻿using System;
namespace MedicalClinic.Domain.Invoice.Entities.Response
{
    public class ResposeSingleInvoice
    {
        public ResposeSingleInvoice()
        {
        }


        public InvoiceItem Item { get; set; }
    }
}
