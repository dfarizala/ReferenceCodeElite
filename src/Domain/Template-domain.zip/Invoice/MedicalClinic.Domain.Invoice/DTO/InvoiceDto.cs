﻿using System;
namespace MedicalClinic.Domain.Invoice.DTO
{
    /// <summary>
    /// DTO Invoice
    /// </summary>
    public class InvoiceDto
    {
        /// <summary>
        /// Name Customer
        /// </summary>
        public string Name { get; set; }
    }
}
