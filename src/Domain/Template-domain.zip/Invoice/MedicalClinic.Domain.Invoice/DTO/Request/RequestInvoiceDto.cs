﻿using System;
namespace MedicalClinic.Domain.Invoice.DTO.Request
{
    public class RequestInvoiceDto
    {
        public RequestInvoiceDto()
        {
        }

        public int Id { get; set; }
    }
}
