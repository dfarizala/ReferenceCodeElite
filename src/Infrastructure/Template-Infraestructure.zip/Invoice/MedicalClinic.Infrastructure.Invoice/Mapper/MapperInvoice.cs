﻿using System;
using AutoMapper;
using MedicalClinic.Domain.Common.Wrappers;
using MedicalClinic.Domain.Invoice.DTO;
using MedicalClinic.Domain.Invoice.DTO.Request;
using MedicalClinic.Domain.Invoice.DTO.Response;
using MedicalClinic.Domain.Invoice.Entities;
using MedicalClinic.Domain.Invoice.Entities.Request;
using MedicalClinic.Domain.Invoice.Entities.Response;

namespace MedicalClinic.Infrastructure.Invoice.Mapper
{
    public class MapperInvoice: Profile
    {
        public MapperInvoice()
        {
            #region Request
            CreateMap<RequestInvoice, RequestInvoiceDto>().ReverseMap();
            CreateMap<InvoiceItem, InvoiceDto>().ReverseMap();
            CreateMap<ResposeSingleInvoice, ResponseSingleInvoiceDto>().ReverseMap();
            CreateMap<Response<ResposeSingleInvoice>, Response<ResponseSingleInvoiceDto>>().ReverseMap();
            #endregion Request

        }
    }
}
