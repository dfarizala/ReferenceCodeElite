﻿using System;
using System.Threading.Tasks;
using MediatR;
using MedicalClinic.Domain.Common.Wrappers;
using MedicalClinic.Domain.Interfaces;
using MedicalClinic.Domain.Invoice.DTO.Response;
using MedicalClinic.Domain.Invoice.Entities.Request;
using MedicalClinic.Domain.Invoice.Entities.Response;
using MedicalClinic.Domain.Invoice.Interfaces.Application;
using Microsoft.Extensions.DependencyInjection;
using Spin.Helper.Injection;

namespace MedicalClinic.Application.Invoice
{
    /// <summary>
    /// Application logic about invoice
    /// </summary>
    public class InvoiceApplication: IInvoiceApplication
    {
        /// <summary>
        /// Executer orchestrattor
        /// </summary>
        private readonly IExecutorOrchestrator _executor;


        public InvoiceApplication(IExecutorOrchestrator executor)
        {
            _executor = executor;
        }

        /// <summary>
        /// Get Invoice
        /// </summary>
        /// <param name="id">Code Invoice</param>
        /// <returns></returns>
        async public Task<Response<ResponseSingleInvoiceDto>> GetInvoice(RequestInvoice request)
        {
            Response<ResponseSingleInvoiceDto> response = null;
            try
            {
                //var aaa = SpinServiceCollection.ServiceProvider.GetRequiredService<IMediator>();

                response = await _executor.ProcessAndMap<RequestInvoice, Response<ResponseSingleInvoiceDto>, Response<ResposeSingleInvoice>>(request);
            }
            catch (Exception ex)
            {

            }

            return response;
        }
    }
}
